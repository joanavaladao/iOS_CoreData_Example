//
//  ViewController.swift
//  myContactList
//
//  Created by Joana Valadao on 05/04/17.
//  Copyright © 2017 Joana Bittencourt. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    // MARK: Properties
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var address: UITextField!

    var contact : NSManagedObject!

    // MARK: ViewController methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Action
    @IBAction func saveContact(_ sender: UIButton) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        // begin Creating a managed object for working with managed objects (store in disk).
        let managedContext = appDelegate.persistentContainer.viewContext
        
        // relating to entity
        let entity = NSEntityDescription.entity(forEntityName: "Contact", in: managedContext)!
        
        let contact = NSManagedObject(entity: entity, insertInto: managedContext)
        
        // saving the value
        contact.setValue(name.text!, forKeyPath: "name")
        contact.setValue(address.text!, forKeyPath: "address")
        contact.setValue(email.text!, forKeyPath: "email")
        contact.setValue(phone.text!, forKeyPath: "phone")
        
        // 4
        do {
            try managedContext.save()
            showMessage(message: "Saved successfully")
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
            showMessage(message: "Could not save. \(error), \(error.userInfo)")
        }
        
        name.text = ""
        phone.text = ""
        email.text = ""
        address.text = ""
    }
    
    @IBAction func searchContact(_ sender: UIButton) {
        
        // Creating a managed object for working with managed objects (store in disk).
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        // Creating a managed object context for working with managed objects.
        let managedContext = appDelegate.persistentContainer.viewContext
        
        // Variable that will receive data retrieved from entity Contact
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Contact")
        
        //3 : Loop to read data store then in people (array created previously
        do {
            let contactList = try managedContext.fetch(fetchRequest)
            let nameSearch = name.text!
            
            var contactFound = false
            
            for i in contactList {
                if let nameContact = i.value(forKeyPath: "Name") as? String {
                    if nameContact == nameSearch {
                        name.text = nameContact
                        phone.text = i.value(forKeyPath: "Phone") as? String ?? ""
                        email.text = i.value(forKeyPath: "Email") as? String ?? ""
                        address.text = i.value(forKeyPath: "Address") as? String ?? ""
                        contactFound = true
                        break
                    }
                }
            } // for
            
            if !contactFound {
                showMessage(message: "Contact not found")
                phone.text = ""
                email.text = ""
                address.text = ""
            }
            
        } catch let error as NSError {
            showMessage(message: "Could not fetch. \(error), \(error.userInfo)")
        }

    }
    
    // MARK: Private Methods
    private func showMessage(message: String){
        // Create a Modal to show message to user
        let message = UIAlertController(title: "",
                                      message: message,
                                      preferredStyle: .alert)
        
        // Create a button save to be used in A Modal
        let okAction = UIAlertAction(title: "Ok", style: .default)
        
        // Adding proprety in Modal
        message.addAction(okAction)
        
        // Show the Modal to the user
        present(message, animated: true)
    }
    


}

